Group 7 (L1)

FILES:
sim bot file: "lizard_green.simmodel"
main python script: "main.py"
custom script : "sensorDistance.py"

NOTE:
All of the Coppeliasim python libraries need to be in same directory as the python scripts.

TO RUN:
- open a coppeliasim map
- import robot file
- run simulation (MUST BE 25ms SIMULATION TIME!!)
- open powershell
- run "python ./main.py"

-enjoy